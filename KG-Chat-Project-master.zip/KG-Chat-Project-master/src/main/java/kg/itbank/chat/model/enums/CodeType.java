package kg.itbank.chat.model.enums;

public enum CodeType {
    LOGIN, REGISTER, MODIFY
}
